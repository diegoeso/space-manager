<?php

use Faker\Generator as Faker;

$factory->define(App\Mensaje::class, function (Faker $faker) {
    return [
        //
    ];
});
