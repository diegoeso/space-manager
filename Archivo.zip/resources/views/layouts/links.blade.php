<!-- Bootstrap 3.3.7 -->
<link href="{{ asset('bower_components/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>
<!-- Select2 -->
<link href="{{ asset('bower_components/select2/dist/css/select2.min.css') }}" rel="stylesheet"/>
<!-- Font Awesome -->
<link href="{{ asset('bower_components/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet"/>
<!-- Ionicons -->
<link href="{{ asset('bower_components/Ionicons/css/ionicons.min.css') }}" rel="stylesheet"/>
{{-- Toastr --}}
<link href="{{ asset('plugins/toastr/toastr.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ asset('bower_components/jquery-alertable-master/jquery.alertable.css') }}" rel="stylesheet"/>
<!-- DataTables -->
<link href="{{ asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
<!-- Theme style -->
<link href="{{ asset('dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>
<link href="{{ asset('dist/css/skins/_all-skins.min.css') }}" rel="stylesheet"/>
<!-- Morris chart -->
<link href="{{ asset('bower_components/morris.js/morris.css') }}" rel="stylesheet"/>
<!-- fullCalendar -->
<link href="{{ asset('bower_components/fullcalendar/dist/fullcalendar.min.css') }}" rel="stylesheet"/>
<link href="{{ asset('bower_components/fullcalendar/dist/fullcalendar.print.min.css') }}" media="print" rel="stylesheet"/>
<!-- jvectormap -->
<link href="{{ asset('bower_components/jvectormap/jquery-jvectormap.css') }}" rel="stylesheet"/>
<!-- Date Picker -->
<link href="{{ asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}" rel="stylesheet"/>
<link href="{{ asset('plugins/datepicker/datepicker.min.css') }}" rel="stylesheet"/>
<!-- Daterange picker -->
<link href="{{ asset('bower_components/bootstrap-daterangepicker/daterangepicker.css') }}" rel="stylesheet"/>
<!-- Bootstrap time Picker -->
<link href="{{ asset('plugins/timepicker/bootstrap-timepicker.min.css') }}" rel="stylesheet"/>
<!-- bootstrap wysihtml5 - text editor -->
<link href="{{ asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css') }}" rel="stylesheet"/>
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic" rel="stylesheet"/>
<!-- iCheck for checkboxes and radio inputs -->
<link href="{{ asset('plugins/iCheck/all.css') }}" rel="stylesheet">
</link>
<script src="https://www.gstatic.com/charts/loader.js" type="text/javascript">
</script>
