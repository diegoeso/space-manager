<div class="box-tools pull-right" style="margin-bottom: 10px;">
    <div class="input-group input-group-sm" style="width: 250px;">
        <input class="form-control pull-right" name="table_search" placeholder="Buscar..." type="text">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit">
                    <i class="fa fa-search">
                    </i>
                </button>
            </div>
        </input>
    </div>
</div>